# m20_udp_bridge

ROS1 Noetic 节点，用 M20 `basic_server` UDP 协议接收实时状态并发布：

- `/IMU`：`m20_udp_bridge/M20Imu`，默认 200 Hz
- `/JOINTS_DATA`：`m20_udp_bridge/M20JointsData`，默认 500 Hz

## 设计

AOS/basic_server 默认地址：

```text
10.21.31.103:30000
```

节点以 1 Hz 发送心跳。收到 `Type=1002, Command=4` 后更新一次真实状态缓存。

如果 UDP 实际只约 10 Hz：

- `/IMU` 在新 UDP 样本之间重复最近值，以 200 Hz 发布；
- `/JOINTS_DATA` 在新 UDP 样本之间重复最近值，以 500 Hz 发布。

为避免混淆“真实 UDP 更新”和“ROS 补发”，消息中保存：

- `source_stamp`
- `source_sequence`
- `repeated`
- `source_age`
- `stale`

## 目录

将整个 `m20_udp_bridge` 文件夹放到：

```text
~/m20_udp_ws/src/m20_udp_bridge
```

## 编译

```bash
mkdir -p ~/m20_udp_ws/src
cp -r m20_udp_bridge ~/m20_udp_ws/src/

cd ~/m20_udp_ws
source /opt/ros/noetic/setup.bash
catkin_make -DCMAKE_BUILD_TYPE=Release
source devel/setup.bash
```

检查：

```bash
rosmsg show m20_udp_bridge/M20Imu
rosmsg show m20_udp_bridge/M20JointsData
```

## 运行

终端 1：

```bash
source /opt/ros/noetic/setup.bash
roscore
```

终端 2：

```bash
source /opt/ros/noetic/setup.bash
source ~/m20_udp_ws/devel/setup.bash
roslaunch m20_udp_bridge m20_udp_bridge.launch
```

如果 Orin IP 不是 `10.21.31.150`：

```bash
roslaunch m20_udp_bridge m20_udp_bridge.launch local_ip:=实际IP
```

查看原始 JSON：

```bash
roslaunch m20_udp_bridge m20_udp_bridge.launch verbose_raw_json:=true
```

## 查看结果

```bash
rostopic list | grep -E '^/IMU$|^/JOINTS_DATA$'

rostopic type /IMU
rostopic type /JOINTS_DATA

rostopic echo -n 1 /IMU
rostopic echo -n 1 /JOINTS_DATA
```

检查频率：

```bash
rostopic hz /IMU
```

另一个终端：

```bash
rostopic hz /JOINTS_DATA
```

检查真实 UDP 更新：

```bash
rostopic echo /IMU/source_sequence
rostopic echo /IMU/repeated
rostopic echo /IMU/source_age
```

`source_sequence` 只有真实 UDP 新包到达时才增加。

## 网络排查

```bash
ping -c 3 10.21.31.103

sudo tcpdump -ni any   'udp and host 10.21.31.103 and port 30000'
```

## 本地假服务器测试

终端 A：

```bash
python3 ~/m20_udp_ws/src/m20_udp_bridge/tools/fake_m20_udp_server.py
```

终端 B：

```bash
source /opt/ros/noetic/setup.bash
source ~/m20_udp_ws/devel/setup.bash

roslaunch m20_udp_bridge m20_udp_bridge.launch   server_ip:=127.0.0.1   local_ip:=127.0.0.1
```

假服务器以 10 Hz 发送真实源样本，可用于验证 `/IMU` 200 Hz 和 `/JOINTS_DATA` 500 Hz 保持发布逻辑。

## 录包

```bash
~/m20_udp_ws/src/m20_udp_bridge/scripts/record_bag.sh
```

脚本默认录制：

```text
/IMU
/JOINTS_DATA
/rslidar_points_front
/rslidar_points_rear
```

也可以手动：

```bash
mkdir -p ~/rosbags
cd ~/rosbags

rosbag record   -O "m20_$(date +%Y%m%d_%H%M%S).bag"   /IMU   /JOINTS_DATA   /rslidar_points_front   /rslidar_points_rear
```
