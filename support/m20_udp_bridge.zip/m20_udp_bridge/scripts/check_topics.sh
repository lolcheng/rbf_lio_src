#!/usr/bin/env bash
set -euo pipefail

source /opt/ros/noetic/setup.bash
source "$HOME/m20_udp_ws/devel/setup.bash"

echo "========== node =========="
rosnode list | grep m20_udp_bridge || true

echo
echo "========== topic types =========="
rostopic type /IMU
rostopic type /JOINTS_DATA

echo
echo "========== one /IMU message =========="
timeout 5 rostopic echo -n 1 /IMU || true

echo
echo "========== one /JOINTS_DATA message =========="
timeout 5 rostopic echo -n 1 /JOINTS_DATA || true

echo
echo "Check rates in two terminals:"
echo "  rostopic hz /IMU"
echo "  rostopic hz /JOINTS_DATA"
