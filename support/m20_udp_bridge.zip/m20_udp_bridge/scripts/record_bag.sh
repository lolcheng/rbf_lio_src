#!/usr/bin/env bash
set -euo pipefail

source /opt/ros/noetic/setup.bash
source "$HOME/m20_udp_ws/devel/setup.bash"

BAG_DIR="$HOME/rosbags"
BAG_NAME="m20_$(date +%Y%m%d_%H%M%S)"

mkdir -p "$BAG_DIR"
cd "$BAG_DIR"

echo "Recording: $BAG_DIR/$BAG_NAME.bag"
echo "Press Ctrl+C to stop cleanly."

rosbag record   -O "$BAG_NAME.bag"   /IMU   /JOINTS_DATA   /rslidar_points_front   /rslidar_points_rear
