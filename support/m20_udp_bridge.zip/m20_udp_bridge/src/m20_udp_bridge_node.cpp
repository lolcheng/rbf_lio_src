#include <ros/ros.h>

#include <m20_udp_bridge/M20Imu.h>
#include <m20_udp_bridge/M20JointsData.h>

#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/ptree.hpp>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace
{

constexpr std::array<uint8_t, 4> kSyncBytes{{0xEB, 0x91, 0xEB, 0x90}};
constexpr std::size_t kHeaderSize = 16;
constexpr uint8_t kJsonFormat = 0x01;

constexpr int kHeartbeatType = 100;
constexpr int kHeartbeatCommand = 100;
constexpr int kStatusType = 1002;
constexpr int kStatusCommand = 4;

uint16_t readLittleEndian16(const uint8_t* data)
{
  return static_cast<uint16_t>(data[0]) |
         static_cast<uint16_t>(static_cast<uint16_t>(data[1]) << 8U);
}

void writeLittleEndian16(uint8_t* data, uint16_t value)
{
  data[0] = static_cast<uint8_t>(value & 0xFFU);
  data[1] = static_cast<uint8_t>((value >> 8U) & 0xFFU);
}

std::string currentLocalTimeString()
{
  const std::time_t current_time = std::time(nullptr);
  std::tm local_time{};
  localtime_r(&current_time, &local_time);

  std::ostringstream output;
  output << std::put_time(&local_time, "%Y-%m-%d %H:%M:%S");
  return output.str();
}

struct CachedStatus
{
  bool valid{false};

  ros::Time source_stamp;
  uint32_t source_sequence{0};
  uint16_t apdu_message_id{0};
  std::string device_time;

  double roll{0.0};
  double pitch{0.0};
  double yaw{0.0};
  double linear_x{0.0};
  double linear_y{0.0};
  double angular_z{0.0};

  double left_front_hip_x{0.0};
  double left_front_hip_y{0.0};
  double left_front_knee{0.0};
  double left_front_wheel{0.0};

  double right_front_hip_x{0.0};
  double right_front_hip_y{0.0};
  double right_front_knee{0.0};
  double right_front_wheel{0.0};

  double left_back_hip_x{0.0};
  double left_back_hip_y{0.0};
  double left_back_knee{0.0};
  double left_back_wheel{0.0};

  double right_back_hip_x{0.0};
  double right_back_hip_y{0.0};
  double right_back_knee{0.0};
  double right_back_wheel{0.0};
};

class M20UdpBridge
{
public:
  M20UdpBridge()
    : nh_(), private_nh_("~")
  {
    private_nh_.param<std::string>("server_ip", server_ip_, "10.21.31.103");
    private_nh_.param<int>("server_port", server_port_, 30000);
    private_nh_.param<std::string>("local_ip", local_ip_, "10.21.31.150");
    private_nh_.param<int>("local_port", local_port_, 0);

    private_nh_.param<double>("heartbeat_hz", heartbeat_hz_, 1.0);
    private_nh_.param<double>("imu_publish_hz", imu_publish_hz_, 200.0);
    private_nh_.param<double>("joints_publish_hz", joints_publish_hz_, 500.0);
    private_nh_.param<double>("stale_timeout", stale_timeout_, 0.5);

    private_nh_.param<std::string>("frame_id", frame_id_, "base_link");
    private_nh_.param<std::string>("imu_topic", imu_topic_, "/IMU");
    private_nh_.param<std::string>("joints_topic", joints_topic_, "/JOINTS_DATA");
    private_nh_.param<bool>("verbose_raw_json", verbose_raw_json_, false);

    validateParameters();
    initialiseSocket();

    imu_publisher_ =
        nh_.advertise<m20_udp_bridge::M20Imu>(imu_topic_, 1000);

    joints_publisher_ =
        nh_.advertise<m20_udp_bridge::M20JointsData>(joints_topic_, 2000);

    heartbeat_timer_ = nh_.createTimer(
        ros::Duration(1.0 / heartbeat_hz_),
        &M20UdpBridge::heartbeatCallback,
        this);

    imu_timer_ = nh_.createTimer(
        ros::Duration(1.0 / imu_publish_hz_),
        &M20UdpBridge::imuPublishCallback,
        this);

    joints_timer_ = nh_.createTimer(
        ros::Duration(1.0 / joints_publish_hz_),
        &M20UdpBridge::jointsPublishCallback,
        this);

    diagnostics_timer_ = nh_.createTimer(
        ros::Duration(2.0),
        &M20UdpBridge::diagnosticsCallback,
        this);

    running_.store(true);
    receive_thread_ = std::thread(&M20UdpBridge::receiveLoop, this);

    // Send the first heartbeat immediately.
    sendHeartbeat();

    ROS_INFO_STREAM("M20 UDP bridge started");
    ROS_INFO_STREAM("UDP server: " << server_ip_ << ":" << server_port_);
    ROS_INFO_STREAM("ROS topics: " << imu_topic_ << " @ "
                    << imu_publish_hz_ << " Hz, "
                    << joints_topic_ << " @ "
                    << joints_publish_hz_ << " Hz");
  }

  ~M20UdpBridge()
  {
    running_.store(false);

    if (socket_fd_ >= 0)
    {
      ::shutdown(socket_fd_, SHUT_RDWR);
      ::close(socket_fd_);
      socket_fd_ = -1;
    }

    if (receive_thread_.joinable())
      receive_thread_.join();
  }

private:
  void validateParameters()
  {
    if (server_port_ <= 0 || server_port_ > 65535)
      throw std::runtime_error("server_port is invalid");

    if (local_port_ < 0 || local_port_ > 65535)
      throw std::runtime_error("local_port is invalid");

    if (heartbeat_hz_ <= 0.0 ||
        imu_publish_hz_ <= 0.0 ||
        joints_publish_hz_ <= 0.0)
      throw std::runtime_error("heartbeat/publish rates must be positive");

    if (stale_timeout_ <= 0.0)
      throw std::runtime_error("stale_timeout must be positive");
  }

  void initialiseSocket()
  {
    socket_fd_ = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (socket_fd_ < 0)
    {
      throw std::runtime_error(
          std::string("socket failed: ") + std::strerror(errno));
    }

    int reuse_address = 1;
    ::setsockopt(
        socket_fd_,
        SOL_SOCKET,
        SO_REUSEADDR,
        &reuse_address,
        sizeof(reuse_address));

    int receive_buffer_size = 4 * 1024 * 1024;
    ::setsockopt(
        socket_fd_,
        SOL_SOCKET,
        SO_RCVBUF,
        &receive_buffer_size,
        sizeof(receive_buffer_size));

    sockaddr_in local_address{};
    local_address.sin_family = AF_INET;
    local_address.sin_port = htons(static_cast<uint16_t>(local_port_));

    if (local_ip_.empty() || local_ip_ == "0.0.0.0")
    {
      local_address.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    else if (::inet_pton(
                 AF_INET,
                 local_ip_.c_str(),
                 &local_address.sin_addr) != 1)
    {
      throw std::runtime_error("Invalid local_ip: " + local_ip_);
    }

    if (::bind(
            socket_fd_,
            reinterpret_cast<sockaddr*>(&local_address),
            sizeof(local_address)) < 0)
    {
      throw std::runtime_error(
          std::string("bind failed: ") + std::strerror(errno));
    }

    server_address_ = {};
    server_address_.sin_family = AF_INET;
    server_address_.sin_port = htons(static_cast<uint16_t>(server_port_));

    if (::inet_pton(
            AF_INET,
            server_ip_.c_str(),
            &server_address_.sin_addr) != 1)
    {
      throw std::runtime_error("Invalid server_ip: " + server_ip_);
    }

    sockaddr_in actual_address{};
    socklen_t actual_length = sizeof(actual_address);

    if (::getsockname(
            socket_fd_,
            reinterpret_cast<sockaddr*>(&actual_address),
            &actual_length) == 0)
    {
      char ip_buffer[INET_ADDRSTRLEN]{};

      ::inet_ntop(
          AF_INET,
          &actual_address.sin_addr,
          ip_buffer,
          sizeof(ip_buffer));

      ROS_INFO_STREAM(
          "UDP socket bound to "
          << ip_buffer
          << ":"
          << ntohs(actual_address.sin_port));
    }
  }

  std::vector<uint8_t> buildHeartbeatPacket()
  {
    const uint16_t current_message_id = next_message_id_++;

    std::ostringstream json_stream;

    json_stream
        << "{\"PatrolDevice\":{"
        << "\"Type\":" << kHeartbeatType << ","
        << "\"Command\":" << kHeartbeatCommand << ","
        << "\"Time\":\"" << currentLocalTimeString() << "\","
        << "\"Items\":{}"
        << "}}";

    const std::string json = json_stream.str();

    if (json.size() > std::numeric_limits<uint16_t>::max())
      throw std::runtime_error("Heartbeat JSON is too long");

    std::vector<uint8_t> packet(kHeaderSize + json.size(), 0U);

    std::copy(
        kSyncBytes.begin(),
        kSyncBytes.end(),
        packet.begin());

    writeLittleEndian16(
        packet.data() + 4,
        static_cast<uint16_t>(json.size()));

    writeLittleEndian16(
        packet.data() + 6,
        current_message_id);

    packet[8] = kJsonFormat;

    std::memcpy(
        packet.data() + kHeaderSize,
        json.data(),
        json.size());

    return packet;
  }

  void sendHeartbeat()
  {
    std::lock_guard<std::mutex> lock(heartbeat_mutex_);

    const std::vector<uint8_t> packet = buildHeartbeatPacket();

    const ssize_t sent = ::sendto(
        socket_fd_,
        packet.data(),
        packet.size(),
        0,
        reinterpret_cast<const sockaddr*>(&server_address_),
        sizeof(server_address_));

    if (sent < 0)
    {
      ROS_WARN_STREAM_THROTTLE(
          2.0,
          "Failed to send heartbeat: "
          << std::strerror(errno));

      return;
    }

    if (static_cast<std::size_t>(sent) != packet.size())
    {
      ROS_WARN_STREAM(
          "Partial heartbeat send: "
          << sent << "/" << packet.size());
    }
  }

  void heartbeatCallback(const ros::TimerEvent&)
  {
    sendHeartbeat();
  }

  bool extractJsonFromPacket(
      const uint8_t* data,
      std::size_t packet_size,
      uint16_t& message_id,
      std::string& json,
      std::string& error_message)
  {
    if (packet_size < kHeaderSize)
    {
      error_message = "packet shorter than 16-byte APDU header";
      return false;
    }

    if (!std::equal(kSyncBytes.begin(), kSyncBytes.end(), data))
    {
      error_message = "invalid synchronization bytes";
      return false;
    }

    const uint16_t asdu_length = readLittleEndian16(data + 4);
    message_id = readLittleEndian16(data + 6);

    if (data[8] != kJsonFormat)
    {
      error_message = "ASDU format is not JSON";
      return false;
    }

    const std::size_t expected_size =
        kHeaderSize + static_cast<std::size_t>(asdu_length);

    if (packet_size < expected_size)
    {
      std::ostringstream output;
      output << "truncated packet, expected "
             << expected_size
             << " bytes, got "
             << packet_size;

      error_message = output.str();
      return false;
    }

    json.assign(
        reinterpret_cast<const char*>(data + kHeaderSize),
        asdu_length);

    while (!json.empty() && json.back() == '\0')
      json.pop_back();

    return true;
  }

  void receiveLoop()
  {
    std::array<uint8_t, 65552> buffer{};

    while (running_.load() && ros::ok())
    {
      pollfd descriptor{};
      descriptor.fd = socket_fd_;
      descriptor.events = POLLIN;

      const int poll_result =
          ::poll(&descriptor, 1, 200);

      if (poll_result < 0)
      {
        if (errno == EINTR)
          continue;

        if (running_.load())
        {
          ROS_ERROR_STREAM(
              "UDP poll failed: "
              << std::strerror(errno));
        }

        break;
      }

      if (poll_result == 0 ||
          !(descriptor.revents & POLLIN))
        continue;

      sockaddr_in source_address{};
      socklen_t source_length =
          sizeof(source_address);

      const ssize_t received_size =
          ::recvfrom(
              socket_fd_,
              buffer.data(),
              buffer.size(),
              0,
              reinterpret_cast<sockaddr*>(&source_address),
              &source_length);

      if (received_size <= 0)
      {
        if (received_size < 0 &&
            errno != EINTR &&
            running_.load())
        {
          ROS_WARN_STREAM_THROTTLE(
              2.0,
              "recvfrom failed: "
              << std::strerror(errno));
        }

        continue;
      }

      handlePacket(
          buffer.data(),
          static_cast<std::size_t>(received_size),
          source_address);
    }
  }

  void handlePacket(
      const uint8_t* data,
      std::size_t packet_size,
      const sockaddr_in& source_address)
  {
    char source_ip_buffer[INET_ADDRSTRLEN]{};

    ::inet_ntop(
        AF_INET,
        &source_address.sin_addr,
        source_ip_buffer,
        sizeof(source_ip_buffer));

    const std::string source_ip(source_ip_buffer);

    if (source_ip != server_ip_)
    {
      ROS_WARN_STREAM_THROTTLE(
          2.0,
          "Ignoring UDP packet from "
          << source_ip);

      return;
    }

    uint16_t message_id = 0;
    std::string json;
    std::string error_message;

    if (!extractJsonFromPacket(
            data,
            packet_size,
            message_id,
            json,
            error_message))
    {
      ROS_WARN_STREAM_THROTTLE(
          2.0,
          "Invalid M20 APDU: "
          << error_message);

      return;
    }

    if (verbose_raw_json_)
      ROS_INFO_STREAM("RX JSON: " << json);

    try
    {
      std::stringstream json_stream(json);
      boost::property_tree::ptree root;

      boost::property_tree::read_json(
          json_stream,
          root);

      const auto& patrol_device =
          root.get_child("PatrolDevice");

      const int type =
          patrol_device.get<int>("Type");

      const int command =
          patrol_device.get<int>("Command");

      if (type != kStatusType ||
          command != kStatusCommand)
        return;

      const auto& motion_status =
          patrol_device.get_child(
              "Items.MotionStatus");

      const auto& motor_status =
          patrol_device.get_child(
              "Items.MotorStatus");

      CachedStatus new_status;

      new_status.valid = true;
      new_status.source_stamp = ros::Time::now();
      new_status.apdu_message_id = message_id;

      new_status.device_time =
          patrol_device.get<std::string>(
              "Time",
              "");

      new_status.roll =
          motion_status.get<double>("Roll");

      new_status.pitch =
          motion_status.get<double>("Pitch");

      new_status.yaw =
          motion_status.get<double>("Yaw");

      new_status.angular_z =
          motion_status.get<double>("OmegaZ");

      new_status.linear_x =
          motion_status.get<double>("LinearX");

      new_status.linear_y =
          motion_status.get<double>("LinearY");

      new_status.left_front_hip_x =
          motor_status.get<double>("LeftFrontHipX");

      new_status.left_front_hip_y =
          motor_status.get<double>("LeftFrontHipY");

      new_status.left_front_knee =
          motor_status.get<double>("LeftFrontKnee");

      new_status.left_front_wheel =
          motor_status.get<double>("LeftFrontWheel");

      new_status.right_front_hip_x =
          motor_status.get<double>("RightFrontHipX");

      new_status.right_front_hip_y =
          motor_status.get<double>("RightFrontHipY");

      new_status.right_front_knee =
          motor_status.get<double>("RightFrontKnee");

      new_status.right_front_wheel =
          motor_status.get<double>("RightFrontWheel");

      new_status.left_back_hip_x =
          motor_status.get<double>("LeftBackHipX");

      new_status.left_back_hip_y =
          motor_status.get<double>("LeftBackHipY");

      new_status.left_back_knee =
          motor_status.get<double>("LeftBackKnee");

      new_status.left_back_wheel =
          motor_status.get<double>("LeftBackWheel");

      new_status.right_back_hip_x =
          motor_status.get<double>("RightBackHipX");

      new_status.right_back_hip_y =
          motor_status.get<double>("RightBackHipY");

      new_status.right_back_knee =
          motor_status.get<double>("RightBackKnee");

      new_status.right_back_wheel =
          motor_status.get<double>("RightBackWheel");

      {
        std::lock_guard<std::mutex> lock(cache_mutex_);

        new_status.source_sequence =
            ++source_sequence_;

        cached_status_ = new_status;
      }

      ++received_status_count_;
    }
    catch (
        const boost::property_tree::ptree_error&
            error)
    {
      ROS_WARN_STREAM_THROTTLE(
          2.0,
          "M20 JSON parse/field error: "
          << error.what());
    }
    catch (
        const std::exception&
            error)
    {
      ROS_WARN_STREAM_THROTTLE(
          2.0,
          "M20 status processing error: "
          << error.what());
    }
  }

  bool copyCachedStatus(CachedStatus& output)
  {
    std::lock_guard<std::mutex> lock(cache_mutex_);

    if (!cached_status_.valid)
      return false;

    output = cached_status_;
    return true;
  }

  void imuPublishCallback(const ros::TimerEvent&)
  {
    std::lock_guard<std::mutex> publish_lock(
        imu_publish_mutex_);

    CachedStatus status;

    if (!copyCachedStatus(status))
      return;

    const ros::Time publish_stamp =
        ros::Time::now();

    double source_age =
        (publish_stamp -
         status.source_stamp).toSec();

    if (source_age < 0.0)
      source_age = 0.0;

    const bool repeated =
        imu_has_published_ &&
        status.source_sequence ==
            last_imu_source_sequence_;

    m20_udp_bridge::M20Imu message;

    message.header.stamp = publish_stamp;
    message.header.frame_id = frame_id_;

    message.source_stamp =
        status.source_stamp;

    message.source_sequence =
        status.source_sequence;

    message.apdu_message_id =
        status.apdu_message_id;

    message.device_time =
        status.device_time;

    message.repeated = repeated;
    message.stale =
        source_age > stale_timeout_;

    message.source_age = source_age;

    message.roll = status.roll;
    message.pitch = status.pitch;
    message.yaw = status.yaw;
    message.linear_x = status.linear_x;
    message.linear_y = status.linear_y;
    message.angular_z = status.angular_z;

    imu_publisher_.publish(message);

    last_imu_source_sequence_ =
        status.source_sequence;

    imu_has_published_ = true;
  }

  void jointsPublishCallback(const ros::TimerEvent&)
  {
    std::lock_guard<std::mutex> publish_lock(
        joints_publish_mutex_);

    CachedStatus status;

    if (!copyCachedStatus(status))
      return;

    const ros::Time publish_stamp =
        ros::Time::now();

    double source_age =
        (publish_stamp -
         status.source_stamp).toSec();

    if (source_age < 0.0)
      source_age = 0.0;

    const bool repeated =
        joints_have_published_ &&
        status.source_sequence ==
            last_joints_source_sequence_;

    m20_udp_bridge::M20JointsData message;

    message.header.stamp = publish_stamp;
    message.header.frame_id = frame_id_;

    message.source_stamp =
        status.source_stamp;

    message.source_sequence =
        status.source_sequence;

    message.apdu_message_id =
        status.apdu_message_id;

    message.device_time =
        status.device_time;

    message.repeated = repeated;
    message.stale =
        source_age > stale_timeout_;

    message.source_age = source_age;

    message.left_front_hip_x =
        status.left_front_hip_x;

    message.left_front_hip_y =
        status.left_front_hip_y;

    message.left_front_knee =
        status.left_front_knee;

    message.left_front_wheel_speed =
        status.left_front_wheel;

    message.right_front_hip_x =
        status.right_front_hip_x;

    message.right_front_hip_y =
        status.right_front_hip_y;

    message.right_front_knee =
        status.right_front_knee;

    message.right_front_wheel_speed =
        status.right_front_wheel;

    message.left_back_hip_x =
        status.left_back_hip_x;

    message.left_back_hip_y =
        status.left_back_hip_y;

    message.left_back_knee =
        status.left_back_knee;

    message.left_back_wheel_speed =
        status.left_back_wheel;

    message.right_back_hip_x =
        status.right_back_hip_x;

    message.right_back_hip_y =
        status.right_back_hip_y;

    message.right_back_knee =
        status.right_back_knee;

    message.right_back_wheel_speed =
        status.right_back_wheel;

    joints_publisher_.publish(message);

    last_joints_source_sequence_ =
        status.source_sequence;

    joints_have_published_ = true;
  }

  void diagnosticsCallback(const ros::TimerEvent&)
  {
    CachedStatus status;

    if (!copyCachedStatus(status))
    {
      ROS_WARN_THROTTLE(
          5.0,
          "No valid M20 UDP status received yet");

      return;
    }

    const double age =
        std::max(
            0.0,
            (ros::Time::now() -
             status.source_stamp).toSec());

    ROS_INFO_STREAM(
        "M20 UDP status count="
        << received_status_count_.load()
        << ", source_sequence="
        << status.source_sequence
        << ", source_age="
        << age
        << " s"
        << ", rpy=["
        << status.roll
        << ", "
        << status.pitch
        << ", "
        << status.yaw
        << "]"
        << ", vxy=["
        << status.linear_x
        << ", "
        << status.linear_y
        << "]"
        << ", wz="
        << status.angular_z);
  }

  ros::NodeHandle nh_;
  ros::NodeHandle private_nh_;

  ros::Publisher imu_publisher_;
  ros::Publisher joints_publisher_;

  ros::Timer heartbeat_timer_;
  ros::Timer imu_timer_;
  ros::Timer joints_timer_;
  ros::Timer diagnostics_timer_;

  int socket_fd_{-1};
  sockaddr_in server_address_{};

  std::string server_ip_;
  int server_port_{30000};

  std::string local_ip_;
  int local_port_{0};

  double heartbeat_hz_{1.0};
  double imu_publish_hz_{200.0};
  double joints_publish_hz_{500.0};
  double stale_timeout_{0.5};

  std::string frame_id_;
  std::string imu_topic_;
  std::string joints_topic_;

  bool verbose_raw_json_{false};

  std::atomic<bool> running_{false};
  std::thread receive_thread_;

  std::mutex heartbeat_mutex_;
  uint16_t next_message_id_{0};

  std::mutex cache_mutex_;
  CachedStatus cached_status_;
  uint32_t source_sequence_{0};

  std::mutex imu_publish_mutex_;
  bool imu_has_published_{false};
  uint32_t last_imu_source_sequence_{0};

  std::mutex joints_publish_mutex_;
  bool joints_have_published_{false};
  uint32_t last_joints_source_sequence_{0};

  std::atomic<uint64_t>
      received_status_count_{0};
};

}  // namespace

int main(int argc, char** argv)
{
  ros::init(
      argc,
      argv,
      "m20_udp_bridge");

  try
  {
    M20UdpBridge bridge;

    ros::AsyncSpinner spinner(4);
    spinner.start();

    ros::waitForShutdown();
  }
  catch (
      const std::exception&
          error)
  {
    ROS_FATAL_STREAM(
        "M20 UDP bridge failed: "
        << error.what());

    return 1;
  }

  return 0;
}
