#!/usr/bin/env python3
"""Local fake server for m20_udp_bridge.

Run:
  python3 fake_m20_udp_server.py

Then launch the ROS node with:
  roslaunch m20_udp_bridge m20_udp_bridge.launch \
    server_ip:=127.0.0.1 local_ip:=127.0.0.1
"""

import argparse
import datetime
import json
import math
import socket
import struct
import time

SYNC = b"\xEB\x91\xEB\x90"
HEADER_SIZE = 16
JSON_FORMAT = 0x01


def now_string():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def build_packet(payload, message_id):
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    header = bytearray(HEADER_SIZE)
    header[:4] = SYNC
    struct.pack_into("<H", header, 4, len(body))
    struct.pack_into("<H", header, 6, message_id & 0xFFFF)
    header[8] = JSON_FORMAT
    return bytes(header) + body


def parse_packet(packet):
    if len(packet) < HEADER_SIZE or packet[:4] != SYNC:
        return None
    length = struct.unpack_from("<H", packet, 4)[0]
    if packet[8] != JSON_FORMAT:
        return None
    if len(packet) < HEADER_SIZE + length:
        return None
    return json.loads(packet[HEADER_SIZE:HEADER_SIZE + length].decode("utf-8"))


def make_status(t):
    s = math.sin(t)
    c = math.cos(t)

    motors = {
        "LeftFrontHipX": 0.10 * s,
        "LeftFrontHipY": 0.20 * c,
        "LeftFrontKnee": 0.30 * s,
        "LeftFrontWheel": 1.0 + 0.2 * s,

        "RightFrontHipX": -0.10 * s,
        "RightFrontHipY": 0.20 * c,
        "RightFrontKnee": -0.30 * s,
        "RightFrontWheel": 1.1 + 0.2 * s,

        "LeftBackHipX": 0.12 * s,
        "LeftBackHipY": -0.18 * c,
        "LeftBackKnee": 0.28 * s,
        "LeftBackWheel": 0.9 + 0.2 * s,

        "RightBackHipX": -0.12 * s,
        "RightBackHipY": -0.18 * c,
        "RightBackKnee": -0.28 * s,
        "RightBackWheel": 1.0 + 0.2 * s,
    }

    return {
        "PatrolDevice": {
            "Type": 1002,
            "Command": 4,
            "Time": now_string(),
            "Items": {
                "MotionStatus": {
                    "Roll": 0.05 * s,
                    "Pitch": 0.03 * c,
                    "Yaw": 0.20 * s,
                    "OmegaZ": 0.10 * c,
                    "LinearX": 0.50 + 0.05 * s,
                    "LinearY": 0.02 * c,
                    "Height": 0.5,
                    "Payload": 0.0,
                    "RemainMile": 1.0,
                },
                "MotorStatus": motors,
            },
        }
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bind-ip", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=30000)
    parser.add_argument("--hz", type=float, default=10.0)
    args = parser.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((args.bind_ip, args.port))
    sock.settimeout(0.02)

    print(f"Fake M20 UDP server listening on {args.bind_ip}:{args.port}")

    client = None
    message_id = 0
    next_send = time.monotonic()
    t0 = time.monotonic()

    while True:
        try:
            packet, source = sock.recvfrom(65535)
            payload = parse_packet(packet)

            if payload:
                patrol = payload.get("PatrolDevice", {})
                if patrol.get("Type") == 100 and patrol.get("Command") == 100:
                    if client != source:
                        print(f"Heartbeat client: {source[0]}:{source[1]}")
                    client = source

        except socket.timeout:
            pass

        now = time.monotonic()

        if client and now >= next_send:
            sock.sendto(
                build_packet(make_status(now - t0), message_id),
                client,
            )

            message_id = (message_id + 1) & 0xFFFF
            next_send += 1.0 / args.hz

            if next_send < now:
                next_send = now + 1.0 / args.hz


if __name__ == "__main__":
    main()
